import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';
import { Instagram, Youtube, Reply } from 'lucide-react';
import { MessageType } from '@shared/schema';

interface SimpleMessageProps {
  message: MessageType;
  isReply?: boolean;
  onReply: (messageId: number) => void;
  senderName: string;
  senderAvatar?: string | null;
}

const SimpleMessage: React.FC<SimpleMessageProps> = ({
  message,
  isReply = false,
  onReply,
  senderName,
  senderAvatar
}) => {
  const formatTimestamp = (timestamp: string) => {
    try {
      return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
    } catch (error) {
      return '(unknown time)';
    }
  };

  return (
    <div className={`w-full p-3 ${isReply ? 'pl-4' : ''}`}>
      <div className={`flex ${message.isOutbound ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={`${message.isOutbound ? 'ml-2' : 'mr-2'} flex-shrink-0`}>
          <Avatar className={`h-8 w-8 ${
            message.isHighIntent && !message.isOutbound 
              ? 'border-2 border-orange-400' 
              : ''
          }`}>
            {senderAvatar ? (
              <AvatarImage src={senderAvatar} />
            ) : (
              <AvatarFallback>
                {message.source === 'instagram' ? <Instagram size={16} /> : <Youtube size={16} />}
              </AvatarFallback>
            )}
          </Avatar>
        </div>
        
        <div className={`flex-1 ${message.isOutbound ? 'items-end' : 'items-start'}`}>
          <div className="flex items-center mb-1">
            <span className="font-semibold text-sm">{senderName}</span>
            <span className="text-gray-500 text-xs ml-2">
              {formatTimestamp(message.timestamp)}
            </span>
            {message.isHighIntent && !message.isOutbound && (
              <Badge variant="outline" className="ml-2 bg-orange-100 text-orange-800 border-orange-200">
                High Intent
              </Badge>
            )}
          </div>
          
          <div className="text-sm whitespace-pre-wrap break-words">
            {message.content || "(No message content)"}
          </div>
          
          {message.reply && message.reply.length > 0 && (
            <div className="mt-2 bg-gray-50 p-2 rounded-md">
              <div className="flex items-center mb-1">
                <span className="font-semibold text-xs">Creator</span>
                {message.isAiGenerated && (
                  <Badge variant="outline" className="ml-2 text-xs">AI Generated</Badge>
                )}
              </div>
              <div className="text-sm text-gray-800">{message.reply}</div>
            </div>
          )}
          
          <div className="mt-2 flex gap-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs" 
              onClick={() => onReply(message.id)}
            >
              <Reply className="h-3 w-3 mr-1" />
              Reply
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SimpleMessage;