import React, { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import SimpleMessage from './SimpleMessage';
import { 
  Instagram, 
  Youtube, 
  Send, 
  ThumbsUp, 
  Loader2,
  AlertCircle,
  MoreHorizontal,
  ArrowLeft,
  Reply
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { apiRequest } from '@/lib/queryClient';
import { MessageType, ThreadType } from '@shared/schema';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

interface ConversationThreadProps {
  threadId: number;
  threadData?: ThreadType;
  onBack?: () => void;
  showBackButton?: boolean;
}

// Default thread for fallback
const defaultThread: ThreadType = {
  id: 0,
  externalParticipantId: '',
  participantName: 'User',
  source: 'instagram' as 'instagram',
  lastMessageAt: new Date().toISOString(),
  status: 'active' as 'active',
  unreadCount: 0
};

const ConversationThread: React.FC<ConversationThreadProps> = ({ 
  threadId, 
  threadData, 
  onBack, 
  showBackButton 
}) => {
  const [replyText, setReplyText] = useState('');
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messageInputRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  
  // Fetch thread info
  const { data: thread, isLoading: isLoadingThread } = useQuery({
    queryKey: ['/api/threads', threadId],
    enabled: !!threadId
  });
  
  // Fetch messages in thread
  const { 
    data: messages, 
    isLoading: isLoadingMessages 
  } = useQuery({
    queryKey: ['/api/threads', threadId, 'messages'],
    enabled: !!threadId
  });

  // Reply mutation
  const { 
    mutate: sendReply, 
    isPending: isSendingReply 
  } = useMutation({
    mutationFn: async (data: { content: string, parentMessageId?: number }) => {
      return apiRequest('POST', `/api/threads/${threadId}/reply`, data);
    },
    onSuccess: () => {
      setReplyText('');
      setReplyingTo(null);
      queryClient.invalidateQueries({ queryKey: ['/api/threads', threadId, 'messages'] });
      queryClient.invalidateQueries({ queryKey: ['/api/threads'] });
      toast({
        title: "Reply sent!",
        description: "Your reply has been sent successfully.",
      });
    },
    onError: (err) => {
      console.error("Error sending reply:", err);
      toast({
        title: "Error sending reply",
        description: "There was an error sending your reply. Please try again.",
        variant: "destructive",
      });
    }
  });

  // AI Generate reply mutation
  const {
    mutate: generateReply,
    isPending: isGeneratingReply
  } = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', `/api/threads/${threadId}/generate-reply`, {});
    },
    onSuccess: (response) => {
      if (response.ok) {
        response.json().then(data => {
          setReplyText(data.reply || '');
        });
      }
      setIsGenerating(false);
    },
    onError: (err) => {
      console.error("Error generating reply:", err);
      toast({
        title: "Error generating reply",
        description: "There was an error generating an AI reply. Please try again.",
        variant: "destructive",
      });
      setIsGenerating(false);
    }
  });

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // Mark thread as read when opened
  useEffect(() => {
    if (threadId) {
      apiRequest('POST', `/api/threads/${threadId}/read`, {});
    }
  }, [threadId]);

  const handleSendReply = () => {
    if (!replyText.trim()) return;
    
    const payload = {
      content: replyText,
      parentMessageId: replyingTo || undefined
    };
    
    sendReply(payload);
  };

  const handleGenerateReply = () => {
    setIsGenerating(true);
    generateReply();
  };

  // Format timestamp for display
  const formatTimestamp = (timestamp: string) => {
    try {
      return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
    } catch (error) {
      return '(unknown time)';
    }
  };

  const getSourceIcon = (source?: string) => {
    switch (source) {
      case 'instagram':
        return <Instagram className="h-4 w-4" />;
      case 'youtube':
        return <Youtube className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  // Thread header with participant info
  const renderThreadHeader = () => {
    // Use thread data with type-safe fallbacks
    const threadInfo: ThreadType = threadData || (thread as ThreadType) || defaultThread;
    
    return (
      <div className="border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-0 bg-white z-10">
        <div className="flex items-center">
          {showBackButton && (
            <Button onClick={onBack} variant="ghost" size="sm" className="mr-2 -ml-2">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          )}
          
          <Avatar className="h-8 w-8 mr-2">
            {threadInfo.participantAvatar ? (
              <AvatarImage src={threadInfo.participantAvatar} />
            ) : (
              <AvatarFallback>
                {getSourceIcon(threadInfo.source)}
              </AvatarFallback>
            )}
          </Avatar>
          
          <div>
            <div className="font-semibold">
              {threadInfo.participantName || 'User'}
            </div>
            <div className="text-xs text-gray-500 flex items-center gap-1">
              {getSourceIcon(threadInfo.source)}
              <span className="capitalize">{threadInfo.source}</span>
              {threadInfo.lastMessageAt && (
                <span className="ml-1">· {formatTimestamp(threadInfo.lastMessageAt)}</span>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex items-center">
          {threadInfo.status === 'active' && (
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Active</Badge>
          )}
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="ml-2">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Mark as Resolved</DropdownMenuItem>
              <DropdownMenuItem>Archive Thread</DropdownMenuItem>
              <DropdownMenuItem>View Profile</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    );
  };

  // Organize messages into a parent-child structure for display
  const getOrganizedMessages = () => {
    if (!Array.isArray(messages) || messages.length === 0) {
      return { parentChildMap: new Map(), topLevelMessages: [] };
    }
    
    console.log("TROUBLESHOOTING - Raw messages data:", JSON.stringify(messages, null, 2));
    
    // Map to track parent-child relationships
    const parentChildMap = new Map<number, number[]>();
    // Set to track which messages are replies
    const replyMessageIds = new Set<number>();
    
    // Build the parent-child relationships - fix for thread display
    messages.forEach(message => {
      // Use a more lenient check for parentMessageId
      // This ensures we catch all types of non-empty parentMessageId values
      if (message.parentMessageId !== null && 
          message.parentMessageId !== undefined && 
          message.parentMessageId !== 0) {
          
        // This is a reply message
        replyMessageIds.add(message.id);
        
        // Add this message as a child of its parent
        if (!parentChildMap.has(message.parentMessageId)) {
          parentChildMap.set(message.parentMessageId, []);
        }
        const children = parentChildMap.get(message.parentMessageId);
        if (children) {
          children.push(message.id);
        }
        
        console.log(`FOUND CHILD MESSAGE: Message ${message.id} is a reply to parent ${message.parentMessageId}`);
      } else {
        console.log(`TOP-LEVEL MESSAGE: Message ${message.id} has no parent`);
      }
    });
    
    // Find top-level messages (not replies)
    const topLevelMessages = messages.filter(message => !replyMessageIds.has(message.id))
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    
    console.log("DETAILED THREAD STRUCTURE:", {
      messageCount: messages.length,
      topLevelCount: topLevelMessages.length,
      topLevelIds: topLevelMessages.map(m => m.id),
      replyCount: replyMessageIds.size,
      replyMsgIds: Array.from(replyMessageIds),
      parentChildMap: Object.fromEntries(parentChildMap.entries())
    });
    
    return { parentChildMap, topLevelMessages };
  };
  
  // Single message component
  const MessageItem = ({ 
    message, 
    isReply = false,
    onReplyClick
  }: { 
    message: MessageType, 
    isReply?: boolean,
    onReplyClick: (id: number) => void  
  }) => {
    // Use thread data with type-safe fallbacks
    const threadInfo: ThreadType = threadData || (thread as ThreadType) || defaultThread;
    
    // For consistent display of sender information
    const senderName = message.isOutbound 
      ? "Creator" 
      : (threadInfo.participantName || message.sender?.name || "User");
    
    const senderAvatar = message.isOutbound 
      ? null 
      : (threadInfo.participantAvatar || message.sender?.avatar);
    
    return (
      <div className={`w-full p-3 ${isReply ? 'pl-4' : ''}`}>
        <div className={`flex ${message.isOutbound ? 'flex-row-reverse' : 'flex-row'}`}>
          <div className={`${message.isOutbound ? 'ml-2' : 'mr-2'} flex-shrink-0`}>
            <Avatar className={`h-8 w-8 ${
              message.isHighIntent && !message.isOutbound 
                ? 'border-2 border-orange-400' 
                : ''
            }`}>
              {senderAvatar ? (
                <AvatarImage src={senderAvatar} />
              ) : (
                <AvatarFallback>
                  {message.source === 'instagram' ? <Instagram size={16} /> : <Youtube size={16} />}
                </AvatarFallback>
              )}
            </Avatar>
          </div>
          
          <div className={`flex-1 ${message.isOutbound ? 'items-end' : 'items-start'}`}>
            <div className="flex items-center mb-1">
              <span className="font-semibold text-sm">{senderName}</span>
              <span className="text-gray-500 text-xs ml-2">
                {formatTimestamp(message.timestamp)}
              </span>
              {message.isHighIntent && !message.isOutbound && (
                <Badge variant="outline" className="ml-2 bg-orange-100 text-orange-800 border-orange-200">
                  High Intent
                </Badge>
              )}
            </div>
            
            <div className="text-sm whitespace-pre-wrap break-words">
              {message.content || "(No message content)"}
            </div>
            
            {message.reply && message.reply.length > 0 && (
              <div className="mt-2 bg-gray-50 p-2 rounded-md">
                <div className="flex items-center mb-1">
                  <span className="font-semibold text-xs">Creator</span>
                  {message.isAiGenerated && (
                    <Badge variant="outline" className="ml-2 text-xs">AI Generated</Badge>
                  )}
                </div>
                <div className="text-sm text-gray-800">{message.reply}</div>
              </div>
            )}
            
            <div className="mt-2 flex gap-2">
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-xs" 
                onClick={() => onReplyClick(message.id)}
              >
                <Reply className="h-3 w-3 mr-1" />
                Reply
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Render messages with parent-child relationships
  const renderMessages = () => {
    if (!Array.isArray(messages) || messages.length === 0) {
      return (
        <div className="flex items-center justify-center h-full text-gray-500">
          No messages yet
        </div>
      );
    }
    
    // Explicitly log all messages with threading details to help debug parent-child relationships
    console.log("Thread messages data with threading info:", 
      messages.map(m => ({
        id: m.id,
        content: m.content?.substring(0, 15),
        parentId: m.parentMessageId,
        isReply: !!m.parentMessageId
      }))
    );
    
    // Helper to organize the messages into parent-child structure
    const getOrganizedThreadMessages = () => {
      // Map to track parent-child relationships  
      const parentChildMap = new Map<number, number[]>();
      
      // Set to track which messages are replies
      const replyMessageIds = new Set<number>();
      
      // CRITICAL FIX - More detailed debug information
      console.log("DEBUGGING PARENT-CHILD RELATIONSHIPS - Raw Message Data:");
      if (Array.isArray(messages)) {
        messages.forEach(msg => {
          console.log(`Message ${msg.id}: parentMessageId=${msg.parentMessageId}, content="${msg.content?.substring(0, 20) || ''}"`);
        });
      }
      
      // Build the parent-child structure with better null check
      if (Array.isArray(messages)) {
        messages.forEach(message => {
          const parentId = message.parentMessageId;
          
          // More thorough parentId check
          if (parentId !== undefined && parentId !== null && parentId > 0) {
            // This is a reply message
            replyMessageIds.add(message.id);
            
            // Add as child to parent
            if (!parentChildMap.has(parentId)) {
              parentChildMap.set(parentId, []);
            }
            
            parentChildMap.get(parentId)?.push(message.id);
            console.log(`✓ REPLY FOUND: Message ${message.id} is a reply to parent ${parentId}`);
          } else {
            console.log(`→ TOP-LEVEL: Message ${message.id} has no parent`);
          }
        });
      }
      
      // Find and sort top-level messages (not replies to anything)
      const topLevelMsgs = Array.isArray(messages) 
        ? messages
            .filter(msg => !replyMessageIds.has(msg.id))
            .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
        : [];
        
      console.log("THREAD VIEW STRUCTURE:", {
        total: messages?.length || 0,
        topLevel: topLevelMsgs.length,
        topLevelIds: topLevelMsgs.map(m => m.id),
        replies: replyMessageIds.size,
        replyIds: Array.from(replyMessageIds),
        parentChildMap: Object.fromEntries(parentChildMap)
      });
      
      return { parentChildMap, topLevelMessages: topLevelMsgs };
    };
    
    const { parentChildMap, topLevelMessages } = getOrganizedThreadMessages();
    
    // Function to render a message with its replies
    const renderMessageWithReplies = (message: MessageType) => {
      // Find child messages (replies to this message)
      const childIds = parentChildMap.get(message.id) || [];
      const childMessages = messages
        .filter(msg => childIds.includes(msg.id))
        .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      
      // Get thread info with type safety for consistent display
      const threadInfo: ThreadType = threadData || (thread as ThreadType) || defaultThread;
      
      return (
        <div key={message.id} className="mb-4">
          {/* Main message */}
          <SimpleMessage 
            message={message} 
            onReply={setReplyingTo}
            senderName={message.isOutbound ? "Creator" : (threadInfo.participantName || message.sender?.name || "User")}
            senderAvatar={message.isOutbound ? null : (threadInfo.participantAvatar || message.sender?.avatar)}
          />
          
          {/* Child messages/replies - only render if this message has replies */}
          {childMessages.length > 0 && (
            <div className="ml-8 border-l-2 border-l-gray-200 pl-3 mt-2 pt-1">
              {/* Add visual thread line with improved styling */}
              <div className="text-xs text-gray-500 mb-1 ml-1">
                {childMessages.length} {childMessages.length === 1 ? 'reply' : 'replies'}
              </div>
              {childMessages.map(childMsg => (
                <SimpleMessage 
                  key={childMsg.id} 
                  message={childMsg} 
                  isReply={true} 
                  onReply={setReplyingTo}
                  senderName={childMsg.isOutbound ? "Creator" : (threadInfo.participantName || childMsg.sender?.name || "User")}
                  senderAvatar={childMsg.isOutbound ? null : (threadInfo.participantAvatar || childMsg.sender?.avatar)}
                />
              ))}
            </div>
          )}
        </div>
      );
    };
    
    // Render all top-level messages with their replies
    return topLevelMessages.map(renderMessageWithReplies);
  };

  // Reply input area
  const renderReplyForm = () => {
    const replyingToMessage = replyingTo !== null && Array.isArray(messages) 
      ? messages.find(m => m.id === replyingTo) 
      : null;
      
    return (
      <div className="border-t border-gray-200 p-4">
        {replyingToMessage && (
          <div className="flex items-start mb-2 bg-gray-50 p-2 rounded-md">
            <div className="flex-1">
              <div className="flex items-center">
                <span className="text-xs font-semibold">
                  Replying to {replyingToMessage.isOutbound ? "Creator" : replyingToMessage.sender?.name || "User"}
                </span>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 text-xs ml-auto" 
                  onClick={() => setReplyingTo(null)}
                >
                  Cancel
                </Button>
              </div>
              <p className="text-xs text-gray-500 truncate">{replyingToMessage.content}</p>
            </div>
          </div>
        )}
        
        <div className="flex items-end gap-2">
          <Textarea
            ref={messageInputRef}
            placeholder="Type your reply..."
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            className="flex-1 min-h-[80px]"
          />
          <div className="flex flex-col gap-2">
            <Button 
              variant="default" 
              size="sm" 
              onClick={handleSendReply} 
              disabled={!replyText.trim() || isSendingReply}
            >
              {isSendingReply ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleGenerateReply}
              disabled={isGenerating || isGeneratingReply}
              title="Generate AI Reply"
            >
              {isGenerating || isGeneratingReply ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <ThumbsUp className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </div>
    );
  };

  // Loading state
  if (isLoadingThread || isLoadingMessages) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Loading conversation...</span>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {renderThreadHeader()}
      
      <div className="flex-1 overflow-y-auto p-4">
        {renderMessages()}
        <div ref={messagesEndRef} />
      </div>
      
      {renderReplyForm()}
    </div>
  );
};

export default ConversationThread;