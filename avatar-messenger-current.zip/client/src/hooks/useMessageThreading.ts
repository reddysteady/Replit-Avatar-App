import { useMemo } from 'react';
import { MessageType } from '@shared/schema';

// Enhanced message type with threading information
export interface ThreadedMessageType extends MessageType {
  isReply: boolean;
  hasReplies: boolean;
  childMessages: number[];
  depth: number;
}

// This hook organizes messages into a threaded structure for display
export function useMessageThreading(messages: MessageType[] | undefined) {
  return useMemo(() => {
    if (!messages || !Array.isArray(messages)) {
      return {
        organizedMessages: [],
        parentChildMap: new Map<number, number[]>(),
        topLevelMessages: [],
      };
    }

    // Sort messages by timestamp
    const sortedMessages = [...messages].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    // Create a map of parent-child relationships
    const parentChildMap = new Map<number, number[]>();
    
    // Track which messages are replies
    const isReply = new Set<number>();
    
    // Track top-level messages (those without a parent)
    const topLevelMessageIds: number[] = [];
    
    // DEBUG: Log the raw messages and their parent IDs
    console.log('RAW MESSAGES WITH PARENT IDs:', 
      sortedMessages.map(m => ({
        id: m.id, 
        content: m.content?.substring(0, 15) || '',
        parentId: m.parentMessageId
      }))
    );
    
    // First pass: identify all parent-child relationships
    sortedMessages.forEach((message) => {
      // Use a more robust check for parentMessageId that handles all non-null, non-zero values
      if (message.parentMessageId !== null && 
          message.parentMessageId !== undefined && 
          message.parentMessageId !== 0) {
          
        // Mark that this message is a reply to a parent
        isReply.add(message.id);
        
        // Add this message as a child of its parent
        const parentId = message.parentMessageId;
        if (!parentChildMap.has(parentId)) {
          parentChildMap.set(parentId, []);
        }
        
        const children = parentChildMap.get(parentId);
        if (children) {
          children.push(message.id);
          console.log(`Found child message: Message ${message.id} is a reply to parent ${parentId}`);
        }
      } else {
        // This is a top-level message (no parent)
        topLevelMessageIds.push(message.id);
        console.log(`Found top-level message: Message ${message.id} has no parent`);
      }
    });
    
    // Add indentation and grouping info to messages
    const organizedMessages: ThreadedMessageType[] = sortedMessages.map(message => ({
      ...message,
      isReply: isReply.has(message.id),
      hasReplies: parentChildMap.has(message.id) && parentChildMap.get(message.id)!.length > 0,
      childMessages: parentChildMap.get(message.id) || [],
      depth: message.parentMessageId ? 1 : 0 // Simple depth calculation for now
    }));
    
    // Log the parent-child map for debugging
    console.log('PARENT-CHILD MAP:', Object.fromEntries(parentChildMap));
    
    // Log all organized threads with their relationships
    console.log('ORGANIZED MESSAGES:', 
      organizedMessages.map(m => ({
        id: m.id, 
        content: m.content?.substring(0, 15) || '',
        parentId: m.parentMessageId,
        hasReplies: m.hasReplies,
        isReply: m.isReply,
        childCount: m.childMessages.length,
        childIds: m.childMessages
      }))
    );
    
    // Get the actual top-level message objects (not just IDs)
    const topLevelMessages = organizedMessages.filter(message => !message.isReply);
    
    console.log('TOP-LEVEL MESSAGES:', topLevelMessages.map(m => m.id));

    return {
      organizedMessages,
      parentChildMap,
      topLevelMessages
    };
  }, [messages]);
}