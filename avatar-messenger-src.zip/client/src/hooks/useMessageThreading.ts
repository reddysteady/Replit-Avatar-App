import { useMemo } from 'react';
import { MessageType } from '@shared/schema';

// Enhanced message type with threading information
export interface ThreadedMessageType extends MessageType {
  isReply: boolean;
  hasReplies: boolean;
  childMessages: number[];
  depth: number;
}

// This hook organizes messages into a threaded structure for display
export function useMessageThreading(messages: MessageType[] | undefined) {
  return useMemo(() => {
    if (!messages || !Array.isArray(messages)) {
      return {
        organizedMessages: [],
        parentChildMap: new Map(),
        topLevelMessages: [],
      };
    }

    // Sort messages by timestamp
    const sortedMessages = [...messages].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    // Create a map of parent-child relationships
    const parentChildMap = new Map<number, number[]>();
    
    // Track which messages are replies
    const isReply = new Set<number>();
    
    // Track top-level messages (those without a parent)
    const topLevelMessageIds: number[] = [];
    
    // First pass: identify all parent-child relationships
    sortedMessages.forEach((message) => {
      if (message.parentMessageId) {
        // Mark that this message is a reply to a parent
        isReply.add(message.id);
        
        // Add this message as a child of its parent
        const parentId = message.parentMessageId;
        if (!parentChildMap.has(parentId)) {
          parentChildMap.set(parentId, []);
        }
        parentChildMap.get(parentId)?.push(message.id);
      } else {
        // This is a top-level message (no parent)
        topLevelMessageIds.push(message.id);
      }
    });
    
    // Add indentation and grouping info to messages
    const organizedMessages: ThreadedMessageType[] = sortedMessages.map(message => ({
      ...message,
      isReply: isReply.has(message.id),
      hasReplies: parentChildMap.has(message.id) && parentChildMap.get(message.id)!.length > 0,
      childMessages: parentChildMap.get(message.id) || [],
      depth: message.parentMessageId ? 1 : 0 // Simple depth calculation for now
    }));
    
    console.log('Organized message threads:', 
      organizedMessages.map(m => ({
        id: m.id, 
        content: m.content?.substring(0, 15) || '',
        parentId: m.parentMessageId,
        hasReplies: m.hasReplies,
        isReply: m.isReply
      }))
    );
    
    // Get the actual top-level message objects (not just IDs)
    const topLevelMessages = organizedMessages.filter(message => !message.isReply);

    return {
      organizedMessages,
      parentChildMap,
      topLevelMessages
    };
  }, [messages]);
}