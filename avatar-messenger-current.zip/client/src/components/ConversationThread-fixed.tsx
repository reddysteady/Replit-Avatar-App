import React, { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Instagram, 
  Youtube, 
  Send, 
  ThumbsUp, 
  Loader2,
  AlertCircle,
  MoreHorizontal,
  ArrowLeft,
  Reply,
  CornerDownRight
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { apiRequest } from '@/lib/queryClient';
import { MessageType, ThreadType } from '@shared/schema';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

interface ConversationThreadProps {
  threadId: number;
  threadData?: any;
  onBack?: () => void;
  showBackButton?: boolean;
}

const ConversationThread: React.FC<ConversationThreadProps> = ({ 
  threadId, 
  threadData, 
  onBack, 
  showBackButton 
}) => {
  const [replyText, setReplyText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  // Fetch thread info
  const { data: thread, isLoading: isLoadingThread } = useQuery({
    queryKey: ['/api/threads', threadId],
    enabled: !!threadId
  });
  
  // Fetch messages in thread
  const { 
    data: messages, 
    isLoading: isLoadingMessages,
    refetch
  } = useQuery({
    queryKey: ['/api/threads', threadId, 'messages'],
    enabled: !!threadId,
  });
  
  // Mark thread as read
  const markAsReadMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/threads/${threadId}/read`);
    },
    onSuccess: () => {
      // Invalidate threads query to update unread counts
      queryClient.invalidateQueries({ queryKey: ['/api/threads'] });
    },
  });
  
  // Send reply mutation
  const sendReplyMutation = useMutation({
    mutationFn: async (replyContent: string) => {
      return await apiRequest('POST', `/api/threads/${threadId}/reply`, { content: replyContent });
    },
    onSuccess: () => {
      setReplyText('');
      toast({
        title: "Reply sent",
        description: "Your message has been sent successfully.",
      });
      // Refetch messages and thread
      refetch();
      queryClient.invalidateQueries({ queryKey: ['/api/threads'] });
    },
    onError: (error) => {
      toast({
        title: "Error sending reply",
        description: "There was a problem sending your reply. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  // AI reply generation
  const generateReplyMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', `/api/threads/${threadId}/generate-reply`);
      return response.json();
    },
    onSuccess: (data) => {
      setReplyText(data.generatedReply || "I'll get back to you on that.");
      setIsGenerating(false);
    },
    onError: () => {
      setReplyText("I'll get back to you on that.");
      setIsGenerating(false);
      toast({
        title: "Error generating reply",
        description: "There was a problem generating a reply. Please try manually.",
        variant: "destructive",
      });
    },
  });
  
  // Handle key press for sending with Enter
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && replyText.trim()) {
      e.preventDefault();
      handleSendReply();
    }
  };
  
  // Handle sending a reply
  const handleSendReply = () => {
    if (!replyText.trim()) return;
    sendReplyMutation.mutate(replyText);
  };
  
  // Handle AI reply generation
  const handleGenerateReply = () => {
    setIsGenerating(true);
    generateReplyMutation.mutate();
  };
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  // Mark thread as read when viewed
  useEffect(() => {
    if (threadId) {
      markAsReadMutation.mutate();
    }
  }, [threadId]);
  
  // Source icon helper
  const getSourceIcon = (source: string) => {
    if (source === 'instagram') {
      return <Instagram className="h-3 w-3 mr-1" />;
    } else if (source === 'youtube') {
      return <Youtube className="h-3 w-3 mr-1" />;
    }
    return null;
  };
  
  // Format timestamp helper
  const formatTimestamp = (timestamp: string) => {
    try {
      return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
    } catch (e) {
      return 'recently';
    }
  };
  
  // Loading state
  if (isLoadingThread || isLoadingMessages) {
    return (
      <div className="h-full flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
      </div>
    );
  }
  
  // Error state when no thread is found
  if (!thread) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 text-center">
        <AlertCircle className="h-16 w-16 text-gray-300 mb-4" />
        <h3 className="text-lg font-medium mb-2">Conversation not found</h3>
        <p className="text-gray-500 max-w-md">
          We couldn't find this conversation. It may have been deleted or you don't have access to it.
        </p>
      </div>
    );
  }
  
  // Render thread header with participant info
  const renderHeader = () => {
    return (
      <div className="px-4 py-3 flex items-center justify-between border-b border-gray-200 bg-white">
        <div className="flex items-center">
          {showBackButton && (
            <div className="md:hidden mr-2">
              <Button 
                variant="default" 
                size="sm" 
                className="bg-blue-500 hover:bg-blue-600 text-white"
                onClick={() => {
                  console.log("Back button clicked");
                  if (onBack && typeof onBack === 'function') {
                    onBack();
                  }
                }}
              >
                <ArrowLeft className="h-5 w-5 mr-1" />
                Back
              </Button>
            </div>
          )}
          <Avatar className={`h-10 w-10 mr-3 ${threadData?.isHighIntent || messages?.[0]?.isHighIntent ? 'ring-2 ring-amber-500' : ''}`}>
            <AvatarImage 
              src={threadData?.participantAvatar || thread?.participantAvatar} 
              alt={threadData?.participantName || thread?.participantName || 'User'} 
            />
            <AvatarFallback>{(threadData?.participantName || thread?.participantName || 'U').charAt(0)}</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-base font-medium">{threadData?.participantName || thread?.participantName || 'User'}</h2>
            <div className="flex items-center text-sm text-gray-500">
              <span className="flex items-center">
                {getSourceIcon(threadData?.source || thread?.source || '')}
                {(threadData?.source || thread?.source) ? 
                  (threadData?.source || thread?.source).charAt(0).toUpperCase() + (threadData?.source || thread?.source).slice(1) 
                  : 'Unknown'}
              </span>
              <span className="mx-2">•</span>
              <span>{formatTimestamp(threadData?.lastMessageAt || thread?.lastMessageAt || new Date().toISOString())}</span>
            </div>
          </div>
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>
              {thread?.status === 'archived' ? 'Unarchive' : 'Archive'}
            </DropdownMenuItem>
            <DropdownMenuItem>
              {thread?.status === 'snoozed' ? 'Unsnooze' : 'Snooze'}
            </DropdownMenuItem>
            <DropdownMenuItem>Delete</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    );
  };
  
  return (
    <div className="flex flex-col h-full bg-white">
      {/* Thread header */}
      {renderHeader()}
      
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-2">
        {Array.isArray(messages) && messages.length > 0 ? (
          <div>
            {messages.map((message: MessageType) => (
              <div 
                key={message.id} 
                className={`w-full px-2 py-3 md:px-4 border-b border-gray-100 last:border-0 ${
                  message.parentMessageId ? 'ml-8 border-l-2 border-l-gray-100 pl-4' : ''
                }`}
              >
                <div className={`flex ${message.isOutbound ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`${message.isOutbound ? 'ml-2' : 'mr-2'} flex-shrink-0`}>
                    {message.parentMessageId && !message.isOutbound ? (
                      <div className="h-5 w-5 flex items-center justify-center">
                        <CornerDownRight className="h-3 w-3 text-gray-400" />
                      </div>
                    ) : (
                      <Avatar className={`h-8 w-8 ${
                        message.isHighIntent && !message.isOutbound 
                          ? 'ring-2 ring-offset-1 ring-amber-500' 
                          : ''
                      }`}>
                        <AvatarImage 
                          src={message.isOutbound ? undefined : message.sender?.avatar} 
                          alt={message.isOutbound ? 'You' : message.sender?.name || 'User'} 
                        />
                        <AvatarFallback>
                          {message.isOutbound ? 'Y' : (message.sender?.name || 'U').charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                  
                  <div className={`flex-1 flex flex-col ${message.isOutbound ? 'items-end' : 'items-start'}`}>
                    <div className="w-full">
                      <div className="text-sm">
                        {message.isAiGenerated && message.isOutbound && (
                          <Badge variant="outline" className="text-xs mb-1 mr-2 bg-blue-100 text-blue-900 border-blue-200 font-medium">
                            AI Generated
                          </Badge>
                        )}
                        
                        <div className="mb-1">{message.content}</div>
                      </div>
                      
                      <div className="flex items-center mt-1">
                        <div className="text-xs text-gray-500">
                          {formatTimestamp(message.timestamp)}
                        </div>
                        
                        {!message.isOutbound && !message.parentMessageId && (
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 ml-2 p-0 hover:bg-gray-100 rounded-full"
                            onClick={() => {
                              setReplyText(`@${message.sender?.name || 'User'} `);
                              document.querySelector('textarea')?.focus();
                            }}
                          >
                            <Reply className="h-3 w-3 text-gray-500" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            No messages yet
          </div>
        )}
      </div>
      
      {/* Reply input */}
      <div className="border-t border-gray-200 p-4 bg-gray-50">
        <Textarea
          value={replyText}
          onChange={(e) => setReplyText(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="Type your reply..."
          className="resize-none mb-2"
          rows={3}
        />
        <div className="flex justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={handleGenerateReply}
            disabled={isGenerating || sendReplyMutation.isPending}
            className="bg-gray-200 hover:bg-gray-300 text-gray-900 border-gray-300"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <ThumbsUp className="mr-2 h-4 w-4" />
                Generate Reply
              </>
            )}
          </Button>
          
          <Button
            onClick={handleSendReply}
            disabled={!replyText.trim() || sendReplyMutation.isPending}
            className="bg-blue-500 hover:bg-blue-600 text-white"
          >
            {sendReplyMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Sending...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Send
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ConversationThread;